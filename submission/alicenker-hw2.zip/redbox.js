// [TO-DO] Please change the color to blue

const fragmentShaderSource = `
precision mediump float;

void main() {
  gl_FragColor = vec4(0.0, 0.0, 1.0, 1.0);
}
`;